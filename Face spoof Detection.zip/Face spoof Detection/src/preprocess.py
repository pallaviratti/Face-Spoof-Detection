import cv2
import os
import numpy as np
from mtcnn import MTCNN

def extract_faces(img_path, size=(128, 128)):
    detector = MTCNN()
    img = cv2.imread(img_path)
    results = detector.detect_faces(img)
    if results:
        x, y, w, h = results[0]['box']
        face = img[y:y+h, x:x+w]
        face = cv2.resize(face, size)
        return face / 255.0
    return None

def load_data(folder):
    X, y = [], []
    for label in ['real', 'spoof']:
        path = os.path.join(folder, label)
        for img_file in os.listdir(path):
            face = extract_faces(os.path.join(path, img_file))
            if face is not None:
                X.append(face)
                y.append(1 if label == 'real' else 0)
    return np.array(X), np.array(y)
