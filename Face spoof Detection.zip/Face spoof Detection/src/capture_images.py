import cv2
import os

def capture_images(label, count=100):
    cap = cv2.VideoCapture(0)
    path = f"dataset/{label}"

    if not os.path.exists(path):
        os.makedirs(path)

    print(f"Capturing {count} images for '{label}'... Press 'q' to quit early.")

    i = 0
    while i < count:
        ret, frame = cap.read()
        if not ret:
            break

        cv2.imshow("Capture - " + label, frame)
        file_path = os.path.join(path, f"{i}.jpg")
        cv2.imwrite(file_path, frame)
        i += 1

        if cv2.waitKey(100) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print(f"Saved {i} images to '{path}'")

# Run this script
if __name__ == "__main__":
    label = input("Enter 'real' or 'spoof': ").strip().lower()
    if label in ['real', 'spoof']:
        capture_images(label, count=100)
    else:
        print("Invalid input. Use 'real' or 'spoof'.")
