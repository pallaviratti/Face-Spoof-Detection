import cv2
import numpy as np
from mtcnn import MTCNN
from tensorflow.keras.models import load_model

model = load_model('models/spoof_detector.h5')
detector = MTCNN()

def detect_face(frame):
    result = detector.detect_faces(frame)
    if result:
        x, y, w, h = result[0]['box']
        face = frame[y:y+h, x:x+w]
        face = cv2.resize(face, (128, 128))
        face = face / 255.0
        return np.expand_dims(face, axis=0)
    return None

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    face = detect_face(frame)
    if face is not None:
        pred = model.predict(face)[0][0]
        label = "Live" if pred > 0.5 else "Spoof"
        color = (0, 255, 0) if pred > 0.5 else (0, 0, 255)
        cv2.putText(frame, label, (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
    cv2.imshow("Face Spoof Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
